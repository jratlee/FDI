---
name: Industrial Futurist
colors:
  surface: '#fafaeb'
  surface-dim: '#dbdbcd'
  surface-bright: '#fafaeb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f5e6'
  surface-container: '#efefe0'
  surface-container-high: '#e9e9db'
  surface-container-highest: '#e3e3d5'
  on-surface: '#1b1c14'
  on-surface-variant: '#5b4137'
  inverse-surface: '#2f3128'
  inverse-on-surface: '#f1f2e3'
  outline: '#907065'
  outline-variant: '#e4beb1'
  surface-tint: '#a83900'
  primary: '#a83900'
  on-primary: '#ffffff'
  primary-container: '#ff5a00'
  on-primary-container: '#511700'
  inverse-primary: '#ffb59a'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2e1'
  on-secondary-container: '#656464'
  tertiary: '#276a46'
  on-tertiary: '#ffffff'
  tertiary-container: '#5d9f76'
  on-tertiary-container: '#00321a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#380d00'
  on-primary-fixed-variant: '#802900'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c9c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#acf2c3'
  tertiary-fixed-dim: '#91d5a8'
  on-tertiary-fixed: '#002110'
  on-tertiary-fixed-variant: '#05522f'
  background: '#fafaeb'
  on-background: '#1b1c14'
  surface-variant: '#e3e3d5'
typography:
  display-lg:
    fontFamily: Archivo Black
    fontSize: 56px
    fontWeight: '900'
    lineHeight: 50px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Archivo Black
    fontSize: 32px
    fontWeight: '900'
    lineHeight: 32px
    letterSpacing: -0.03em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-bold:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 24px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '800'
    lineHeight: 16px
    letterSpacing: 0.05em
spacing:
  unit: 16px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  border-thin: 1px
  border-thick: 2px
---

## Brand & Style

This design system embodies an **Industrial Futurist** aesthetic, characterized by an uncompromising, rigid, and authoritative personality. It draws inspiration from municipal command stations, physical ledger terminals, and the raw utility of urban infrastructure. The visual language rejects contemporary "softness" in favor of **Brutalism**, utilizing high-contrast color pairings and a strict geometric grid.

The target audience consists of professionals navigating complex regulatory environments who require a UI that feels like a precision tool rather than a lifestyle app. The emotional response is one of clarity, urgency, and absolute structural integrity.

**Key Stylistic Pillars:**
- **Zero Softness:** An absolute 0px border-radius policy across all elements.
- **Mechanical Precision:** Monospaced data displays and architectural typography.
- **High-Contrast Urgency:** A stark palette designed for legibility under harsh conditions, utilizing vibrant safety indicators against deep, structural backdrops.

## Colors

The palette is bifurcated between historic bureaucratic weights and modern industrial safety.

- **Primary (Safety Orange):** Reserved for active alerts, critical interactive states, and high-visibility highlights. It signals "active" or "action required."
- **Secondary (Obsidian):** The structural anchor. Used for heavy borders, dark terminal backgrounds, and primary text headers.
- **Neutral (Ecru/Cream):** The primary canvas color, referencing historic legal paper and municipal archives. It provides a softer ground for dense text than pure white, reducing eye strain during long-term data analysis.
- **Accents:** **Forest Green** represents civic authority and positive compliance, while **Official Warning Red** is strictly reserved for violations and hazards. **Deep Navy** identifies governmental data layers and formal filings.

**Color Application:**
Borders should predominantly use **Obsidian** or **Industrial Gray**. In dark mode transitions, the background shifts to Obsidian with Cream or Safety Orange text.

## Typography

Typography is treated as a structural element. 
- **Archivo Black** is used for massive, architectural display titles. These should always be uppercase with tight tracking to mimic heavy-duty metal stamping.
- **Space Grotesk** handles the primary UI logic and body text, providing a modern, technical feel that remains highly legible.
- **JetBrains Mono** is the "data layer." Use this for all numerical values, legal citations, timestamps, and code IDs. Its fixed-width nature ensures that columns of data align perfectly, reinforcing the mechanical terminal aesthetic.

**Rules:**
1. Never use italics; authority is expressed through weight and casing.
2. Use uppercase for all labels and headers to maintain a commanding presence.
3. Numerical data should always be right-aligned when in tables to leverage the monospaced alignment.

## Layout & Spacing

This design system utilizes a **Fixed Grid** philosophy centered on a 1400px maximum width. The layout is modeled after technical blueprints and inspection reports.

**Grid System:**
- **Desktop:** 12-column grid with 16px gutters.
- **Tablet:** 6-column grid with 16px gutters.
- **Mobile:** 2-column grid with 16px gutters.

**Spacing Rhythm:**
Spacing is dense and functional. Instead of wide "breathing room," we use **Obsidian** borders to create separation. Elements are often packed tightly together, separated by 1px or 2px solid lines. This creates a "paneled" look similar to a physical control console. 

**Implementation Note:**
To achieve the sharp industrial look, use `gap: 2px` on a container with an `Obsidian` background, allowing the background color to bleed through as the border between child elements.

## Elevation & Depth

Depth is conveyed through **Tonal Layers** and **Bold Borders** rather than shadows. In this design system, shadows are non-existent.

- **Flat Hierarchy:** Physical depth is represented by stacking high-contrast containers. An element is "higher" in the hierarchy if it has a thicker border (2px vs 1px) or if it uses the **Safety Orange** accent.
- **Structural Insets:** Use inset borders or darker background shades (Industrial Gray) to simulate recessed areas, like input fields or data wells.
- **Layering:** When a modal or pop-up is required, it should not have a soft shadow. Instead, give it a thick 2px solid Obsidian border and a high-contrast background, potentially with a solid color offset "shadow" (a 100% opaque black rectangle shifted 4px down and right) to mimic brutalist print design.

## Shapes

The shape language is strictly **Sharp (0)**. There are no exceptions. 

Every button, input, card, and tag is a perfect rectangle. This reinforces the "unyielding" brand personality and the mechanical nature of the interface. Even interactive elements like checkboxes must be perfectly square. 

Visual interest is created through the intersection of lines and the contrast of color blocks, rather than organic curves.

## Components

### Buttons
- **Primary:** Solid Safety Orange background, Obsidian text, Archivo Black uppercase.
- **Secondary:** Solid Obsidian background, Cream text, Archivo Black uppercase.
- **Ghost:** Transparent background, 2px solid Obsidian border, Obsidian text.
- **Interaction:** Hover states should be instant (0ms transition). Focus state is a 2px Safety Orange outer stroke. On click, apply a subtle `scale(0.98)` to simulate a mechanical button press.

### Input Fields
- **Default:** 2px solid Obsidian border, white background, JetBrains Mono text.
- **Active/Focus:** Border color shifts instantly to Safety Orange.
- **Labels:** Small, uppercase Space Grotesk (label-caps) placed directly above the input.

### Cards & Containers
- **Standard Card:** 1px or 2px solid Obsidian border, Ecru background.
- **Violation Card:** 2px solid Warning Red border, Red text, monospaced citation codes in the corner.
- **Header Bars:** Solid Obsidian background with Cream text for section headers.

### Specialized Components
- **Compliance Timeline:** A vertical 2px solid line with monospaced "Year" labels on the left. Event "bars" are solid blocks of color (Navy, Green, or Red) with 0px radius.
- **Status Chips:** Rectangular boxes with monospaced text. No rounded corners. Background color indicates status (e.g., Green for "Compliant").
- **Data Grids:** High-density tables with 1px Industrial Gray internal borders. All header text is bold, uppercase, and left-aligned, while numerical data is right-aligned.